from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def test_hnie_school_yaml() -> None:
    text = (ROOT / "schools" / "hnie.yaml").read_text("utf-8")
    assert "vendor: qiangzhi" in text
    assert "jwcmis.hnie.edu.cn/jsxsd/" in text
    assert "last_verified: pending" in text
